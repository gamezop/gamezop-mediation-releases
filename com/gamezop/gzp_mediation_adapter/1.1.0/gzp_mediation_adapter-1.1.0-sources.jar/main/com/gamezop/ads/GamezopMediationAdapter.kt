package com.gamezop.ads

import android.Manifest
import android.app.Activity
import android.content.Context
import android.util.Log
import android.view.View
import androidx.annotation.RequiresPermission
import com.google.android.gms.ads.*
import com.google.android.gms.ads.appopen.AppOpenAd
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.mediation.*
import com.google.android.gms.ads.mediation.VersionInfo
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import com.google.android.gms.ads.rewardedinterstitial.RewardedInterstitialAd
import com.google.android.gms.ads.rewardedinterstitial.RewardedInterstitialAdLoadCallback

/**

* AdMob mediation adapter for Gamezop ads.
* Supports: Banner, Interstitial, Rewarded, Rewarded Interstitial, Native (barebones), App Open.
  */
  class GamezopMediationAdapter : Adapter() {

  private var gamezopAdView: AdView? = null
  private var bannerAdCallback: MediationBannerAdCallback? = null
  private var interstitialAd: InterstitialAd? = null
  private var interstitialAdCallback: MediationInterstitialAdCallback? = null
  private var rewardedAd: RewardedAd? = null
  private var rewardedAdCallback: MediationRewardedAdCallback? = null
  private var rewardedInterstitialAd: RewardedInterstitialAd? = null
  private var rewardedInterstitialAdCallback: MediationRewardedAdCallback? = null
  private var appOpenAd: AppOpenAd? = null
  private var appOpenAdCallback: MediationAppOpenAdCallback? = null
  private var nativeAd: NativeAd? = null
  private var nativeAdCallback: MediationNativeAdCallback? = null

  // Inner classes
  private inner class GamezopBannerAd(private val adView: AdView) : MediationBannerAd {
  override fun getView(): View = adView
  }

  private inner class GamezopInterstitialAd(
  private val interstitial: InterstitialAd
  ) : MediationInterstitialAd {
  override fun showAd(context: Context) {
  val activity = context as? Activity
  ?: throw IllegalArgumentException("Context must be an Activity")
  interstitial.show(activity)
  }
  }

  private inner class GamezopRewardedAd(private val rewarded: RewardedAd) : MediationRewardedAd {
  override fun showAd(context: Context) {
  val activity = context as? Activity
  ?: throw IllegalArgumentException("Context must be an Activity")
  rewarded.show(activity) { rewardItem ->
  rewardedAdCallback?.onUserEarnedReward(rewardItem)
  }
  }
  }

  private inner class GamezopRewardedInterstitialAd(
  private val rewardedInterstitial: RewardedInterstitialAd
  ) : MediationRewardedAd {
  override fun showAd(context: Context) {
  val activity = context as? Activity
  ?: throw IllegalArgumentException("Context must be an Activity")
  rewardedInterstitial.show(activity) { rewardItem ->
  rewardedInterstitialAdCallback?.onUserEarnedReward(rewardItem)
  }
  }
  }

  private inner class GamezopAppOpenAd(private val appOpen: AppOpenAd) : MediationAppOpenAd {
  override fun showAd(context: Context) {
  val activity = context as? Activity
  ?: throw IllegalArgumentException("Context must be an Activity")
  appOpen.show(activity)
  }
  }

  companion object {
  private const val TAG = "GamezopMediation"
  private const val ADAPTER_VERSION_MAJOR = 1
  private const val ADAPTER_VERSION_MINOR = 0
  private const val ADAPTER_VERSION_MICRO = 0
  private const val SDK_VERSION_MAJOR = 22
  private const val SDK_VERSION_MINOR = 4
  private const val SDK_VERSION_MICRO = 0
  }

  override fun initialize(
  context: Context,
  initializationCompleteCallback: InitializationCompleteCallback,
  mediationConfigurations: List<MediationConfiguration>
  ) {
  Log.d(TAG, "Initializing Gamezop mediation adapter")
  initializationCompleteCallback.onInitializationSucceeded()
  }

  override fun getVersionInfo(): VersionInfo = VersionInfo(
  ADAPTER_VERSION_MAJOR, ADAPTER_VERSION_MINOR, ADAPTER_VERSION_MICRO
  )

  override fun getSDKVersionInfo(): VersionInfo = VersionInfo(
  SDK_VERSION_MAJOR, SDK_VERSION_MINOR, SDK_VERSION_MICRO
  )
    // Banner Ads
  @RequiresPermission(Manifest.permission.INTERNET)
  override fun loadBannerAd(
  adConfiguration: MediationBannerAdConfiguration,
  callback: MediationAdLoadCallback<MediationBannerAd, MediationBannerAdCallback>
  ) {
  val context = adConfiguration.context
  val adUnitId = adConfiguration.serverParameters.getString("parameter")
  ?: return callback.onFailure(AdError(0, "Gamezop ad unit ID not provided", TAG))

   gamezopAdView = AdView(context).apply {
       this.adUnitId = adUnitId
       setAdSize(adConfiguration.adSize)
       adListener = object : AdListener() {
           override fun onAdLoaded() {
               Log.d(TAG, "Gamezop banner ad loaded successfully")
               val bannerAd = GamezopBannerAd(this@apply)
               bannerAdCallback = callback.onSuccess(bannerAd)
           }

           override fun onAdFailedToLoad(error: LoadAdError) {
               Log.e(TAG, "Gamezop banner ad failed to load: ${error.message}")
               callback.onFailure(error)
           }

           override fun onAdClicked() {
               Log.d(TAG, "Gamezop banner ad clicked")
               bannerAdCallback?.reportAdClicked()
           }

           override fun onAdImpression() {
               Log.d(TAG, "Gamezop banner ad impression recorded")
               bannerAdCallback?.reportAdImpression()
           }
       }
   }
   gamezopAdView?.loadAd(AdRequest.Builder().build())

  }
    // Interstitial Ads
  @RequiresPermission(Manifest.permission.INTERNET)
  override fun loadInterstitialAd(
  adConfiguration: MediationInterstitialAdConfiguration,
  callback: MediationAdLoadCallback<MediationInterstitialAd, MediationInterstitialAdCallback>
  ) {
  val context = adConfiguration.context
  val adUnitId = adConfiguration.serverParameters.getString("parameter")
  ?: return callback.onFailure(AdError(0, "Gamezop interstitial ad unit ID not provided", TAG))

   InterstitialAd.load(
       context,
       adUnitId,
       AdRequest.Builder().build(),
       object : InterstitialAdLoadCallback() {
           override fun onAdLoaded(ad: InterstitialAd) {
               Log.d(TAG, "Gamezop interstitial ad loaded successfully")
               interstitialAd = ad
               val mediationAd = GamezopInterstitialAd(ad)
               interstitialAdCallback = callback.onSuccess(mediationAd)

               ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                   override fun onAdShowedFullScreenContent() {
                       Log.d(TAG, "Gamezop interstitial ad showed full screen content")
                       interstitialAdCallback?.onAdOpened()
                   }

                   override fun onAdDismissedFullScreenContent() {
                       Log.d(TAG, "Gamezop interstitial ad dismissed full screen content")
                       interstitialAdCallback?.onAdClosed()
                   }

                   override fun onAdImpression() {
                       Log.d(TAG, "Gamezop interstitial ad impression recorded")
                       interstitialAdCallback?.reportAdImpression()
                   }

                   override fun onAdClicked() {
                       Log.d(TAG, "Gamezop interstitial ad clicked")
                       interstitialAdCallback?.reportAdClicked()
                   }

                   override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                       Log.e(TAG, "Gamezop interstitial ad failed to show: ${adError.message}")
                   }
               }
           }

           override fun onAdFailedToLoad(error: LoadAdError) {
               Log.e(TAG, "Gamezop interstitial ad failed: ${error.message}")
               callback.onFailure(error)
           }
       }
   )

  }

  //  Rewarded Ads
  @RequiresPermission(Manifest.permission.INTERNET)
  override fun loadRewardedAd(
  adConfiguration: MediationRewardedAdConfiguration,
  callback: MediationAdLoadCallback<MediationRewardedAd, MediationRewardedAdCallback>
  ) {
  val context = adConfiguration.context
  val adUnitId = adConfiguration.serverParameters.getString("parameter")
  ?: return callback.onFailure(AdError(0, "Gamezop rewarded ad unit ID not provided", TAG))

   RewardedAd.load(
       context,
       adUnitId,
       AdRequest.Builder().build(),
       object : RewardedAdLoadCallback() {
           override fun onAdLoaded(ad: RewardedAd) {
               Log.d(TAG, "Gamezop rewarded ad loaded successfully")
               rewardedAd = ad
               val mediationAd = GamezopRewardedAd(ad)
               rewardedAdCallback = callback.onSuccess(mediationAd)

               ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                   override fun onAdShowedFullScreenContent() {
                       Log.d(TAG, "Gamezop rewarded ad showed full screen content")
                       rewardedAdCallback?.onAdOpened()
                   }

                   override fun onAdDismissedFullScreenContent() {
                       Log.d(TAG, "Gamezop rewarded ad dismissed full screen content")
                       rewardedAdCallback?.onAdClosed()
                   }

                   override fun onAdImpression() {
                       Log.d(TAG, "Gamezop rewarded ad impression recorded")
                       rewardedAdCallback?.reportAdImpression()
                   }

                   override fun onAdClicked() {
                       Log.d(TAG, "Gamezop rewarded ad clicked")
                       rewardedAdCallback?.reportAdClicked()
                   }

                   override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                       Log.e(TAG, "Gamezop rewarded ad failed to show: ${adError.message}")
                   }
               }
           }

           override fun onAdFailedToLoad(error: LoadAdError) {
               Log.e(TAG, "Gamezop rewarded ad failed: ${error.message}")
               callback.onFailure(error)
           }
       }
   )

  }

  //  Rewarded Interstitial Ads
  @RequiresPermission(Manifest.permission.INTERNET)
  override fun loadRewardedInterstitialAd(
  adConfiguration: MediationRewardedAdConfiguration,
  callback: MediationAdLoadCallback<MediationRewardedAd, MediationRewardedAdCallback>
  ) {
  val context = adConfiguration.context
  val adUnitId = adConfiguration.serverParameters.getString("parameter")
  ?: return callback.onFailure(AdError(0, "Gamezop rewarded interstitial ad unit ID not provided", TAG))


   RewardedInterstitialAd.load(
       context,
       adUnitId,
       AdRequest.Builder().build(),
       object : RewardedInterstitialAdLoadCallback() {
           override fun onAdLoaded(ad: RewardedInterstitialAd) {
               Log.d(TAG, "Gamezop rewarded interstitial ad loaded successfully")
               rewardedInterstitialAd = ad
               val mediationAd = GamezopRewardedInterstitialAd(ad)
               rewardedInterstitialAdCallback = callback.onSuccess(mediationAd)

               ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                   override fun onAdShowedFullScreenContent() {
                       Log.d(TAG, "Gamezop rewarded interstitial ad showed full screen content")
                       rewardedInterstitialAdCallback?.onAdOpened()
                   }

                   override fun onAdDismissedFullScreenContent() {
                       Log.d(TAG, "Gamezop rewarded interstitial ad dismissed full screen content")
                       rewardedInterstitialAdCallback?.onAdClosed()
                   }

                   override fun onAdImpression() {
                       Log.d(TAG, "Gamezop rewarded interstitial ad impression recorded")
                       rewardedInterstitialAdCallback?.reportAdImpression()
                   }

                   override fun onAdClicked() {
                       Log.d(TAG, "Gamezop rewarded interstitial ad clicked")
                       rewardedInterstitialAdCallback?.reportAdClicked()
                   }

                   override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                       Log.e(TAG, "Gamezop rewarded interstitial ad failed to show: ${adError.message}")
                   }
               }
           }

           override fun onAdFailedToLoad(error: LoadAdError) {
               Log.e(TAG, "Gamezop rewarded interstitial ad failed: ${error.message}")
               callback.onFailure(error)
           }
       }
   )

  }
    // Native Ads
    @RequiresPermission(Manifest.permission.INTERNET)
    override fun loadNativeAd(
        adConfiguration: MediationNativeAdConfiguration,
        callback: MediationAdLoadCallback<UnifiedNativeAdMapper, MediationNativeAdCallback>
    ) {
        val context = adConfiguration.context
        val adUnitId = adConfiguration.serverParameters.getString("parameter")
            ?: return callback.onFailure(AdError(0, "Gamezop native ad unit ID not provided", TAG))

        val adLoader = AdLoader.Builder(context, adUnitId)
            .forNativeAd { ad ->
                Log.d(TAG, "Gamezop native ad loaded successfully")
                nativeAd = ad

                val mapper = object : UnifiedNativeAdMapper() {
                    init {
                        headline = ad.headline ?: ""
                        callToAction = ad.callToAction ?: ""
                        overrideClickHandling = false
                        overrideImpressionRecording = false
                    }
                }



                nativeAdCallback = callback.onSuccess(mapper)
            }
            .withAdListener(object : AdListener() {
                override fun onAdFailedToLoad(error: LoadAdError) {
                    Log.e(TAG, "Gamezop native ad failed: ${error.message}")
                    callback.onFailure(error)
                }
            })
            .build()

        adLoader.loadAd(AdRequest.Builder().build())
    }


    //  App Open Ads
  @RequiresPermission(Manifest.permission.INTERNET)
  override fun loadAppOpenAd(
  adConfiguration: MediationAppOpenAdConfiguration,
  callback: MediationAdLoadCallback<MediationAppOpenAd, MediationAppOpenAdCallback>
  ) {
  val context = adConfiguration.context
  val adUnitId = adConfiguration.serverParameters.getString("parameter")
  ?: return callback.onFailure(AdError(0, "Gamezop app open ad unit ID not provided", TAG))

   AppOpenAd.load(
       context,
       adUnitId,
       AdRequest.Builder().build(),
       AppOpenAd.APP_OPEN_AD_ORIENTATION_PORTRAIT,
       object : AppOpenAd.AppOpenAdLoadCallback() {
           override fun onAdLoaded(ad: AppOpenAd) {
               Log.d(TAG, "Gamezop app open ad loaded successfully")
               appOpenAd = ad
               val mediationAd = GamezopAppOpenAd(ad)
               appOpenAdCallback = callback.onSuccess(mediationAd)

               ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                   override fun onAdShowedFullScreenContent() {
                       Log.d(TAG, "Gamezop app open ad showed full screen content")
                       appOpenAdCallback?.onAdOpened()
                   }

                   override fun onAdDismissedFullScreenContent() {
                       Log.d(TAG, "Gamezop app open ad dismissed full screen content")
                       appOpenAdCallback?.onAdClosed()
                   }

                   override fun onAdImpression() {
                       Log.d(TAG, "Gamezop app open ad impression recorded")
                       appOpenAdCallback?.reportAdImpression()
                   }

                   override fun onAdClicked() {
                       Log.d(TAG, "Gamezop app open ad clicked")
                       appOpenAdCallback?.reportAdClicked()
                   }

                   override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                       Log.e(TAG, "Gamezop app open ad failed to show: ${adError.message}")
                   }
               }
           }

           override fun onAdFailedToLoad(error: LoadAdError) {
               Log.e(TAG, "Gamezop app open ad failed: ${error.message}")
               callback.onFailure(error)
           }
       }
   )

  }
  }
